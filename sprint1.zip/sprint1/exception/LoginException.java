package com.sprint1.exception;

public class LoginException {
}
