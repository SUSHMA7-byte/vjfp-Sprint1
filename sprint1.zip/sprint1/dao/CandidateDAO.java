package com.sprint1.dao;

public class CandidateDAO {
}
