package com.sprint1.service.notification;

public interface Notification {
    void send(String recipient, String message);
}
